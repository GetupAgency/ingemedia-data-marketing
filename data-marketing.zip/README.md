# Application Marketing CMD

Cette application est un outil de marketing digital qui permet de visualiser et d'analyser des données marketing. Elle est construite avec React, TypeScript, et utilise Vite comme bundler.

## Prérequis

Avant de commencer, assurez-vous d'avoir installé :

- [Node.js](https://nodejs.org/) (version 18 ou supérieure)
- [Git](https://git-scm.com/)
- [Cursor IDE](https://cursor.sh/) (recommandé pour ce projet)

## Installation

1. Clonez le dépôt :
```bash
git clone [URL_DU_REPO]
```

2. Naviguez dans le dossier du projet :
```bash
cd cmd-marketing-app
```

3. Vérifiez que vous êtes dans le bon dossier :
```bash
pwd  # devrait afficher .../cmd-marketing-app
ls   # devrait afficher package.json, src/, etc.
```

4. Installez les dépendances :
```bash
npm install
```

## Lancement du projet

⚠️ **Important** : Assurez-vous d'être dans le dossier `cmd-marketing-app` avant d'exécuter les commandes npm.

Pour lancer l'application en mode développement :

```bash
# Vérifiez que vous êtes dans le bon dossier
pwd  # devrait afficher .../cmd-marketing-app

# Si vous rencontrez des erreurs, essayez de réinstaller les dépendances :
rm -rf node_modules package-lock.json
npm install

# Lancez l'application
npm run dev
```

L'application sera accessible à l'adresse : [http://localhost:5173](http://localhost:5173)

## Structure du projet

```
cmd-marketing-app/
├── src/                    # Code source
│   ├── components/         # Composants React
│   ├── data/              # Données statiques
│   ├── pages/             # Pages de l'application
│   └── utils/             # Utilitaires
├── public/                # Fichiers statiques
└── ...
```

## Commandes disponibles

- `npm run dev` : Lance le serveur de développement
- `npm run build` : Compile le projet pour la production
- `npm run lint` : Vérifie le code avec ESLint
- `npm run preview` : Prévisualise la version de production

## Fonctionnalités principales

- Visualisation de données marketing
- Tutoriels et guides
- Tableaux de bord interactifs
- Analyse de données

## Technologies utilisées

- React 19
- TypeScript
- Vite
- Tailwind CSS
- Chart.js
- React Router
- Axios

## Support

Pour toute question ou problème, n'hésitez pas à :
1. Consulter la documentation
2. Ouvrir une issue sur le dépôt
3. Contacter l'équipe de support

## Bonnes pratiques de développement

1. Toujours créer une nouvelle branche pour vos modifications
2. Suivre les conventions de nommage
3. Écrire des tests unitaires
4. Documenter votre code
5. Utiliser ESLint pour maintenir la qualité du code

## Configuration des API Google

Pour utiliser les fonctionnalités d'intégration avec Google Analytics et Search Console, vous devez configurer les API Google :

1. Créer un projet dans la [Google Cloud Console](https://console.cloud.google.com/)
2. Activer les API suivantes :
   - Google Analytics Data API v1
   - Google Search Console API
3. Créer des identifiants OAuth 2.0 pour une application web
4. Créer un fichier `.env` à la racine du projet avec les variables suivantes :
   ```
   VITE_GOOGLE_CLIENT_ID=votre-client-id
   VITE_GOOGLE_API_KEY=votre-api-key
   ```

## Utilisation de l'analyseur CSV

L'application vous permet d'importer et d'analyser des fichiers CSV provenant de Google Analytics ou Search Console. Formats pris en charge :

- Google Analytics 4
- Google Search Console
- Google Analytics Universal (ancienne version)
- Autres formats CSV avec des colonnes de chemin/URL et métriques

## Développement

```bash
# Lancer le serveur de développement
npm run dev

# Construire pour la production
npm run build

# Prévisualiser la version de production
npm run preview
```

## Contribution

Les contributions sont les bienvenues ! Pour contribuer :

1. Forkez le projet
2. Créez une branche pour votre fonctionnalité (`git checkout -b feature/nouvelle-fonctionnalite`)
3. Committez vos changements (`git commit -m 'Ajout d'une nouvelle fonctionnalité'`)
4. Pushez vers la branche (`git push origin feature/nouvelle-fonctionnalite`)
5. Ouvrez une Pull Request
