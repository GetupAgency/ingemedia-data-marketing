# Guide d'Analyse Data Marketing - Déco Charpente

## 🎯 Objectif du Projet

Analyser les données marketing de **Déco Charpente** pour identifier les leviers de croissance et optimiser la stratégie digitale.

## 📊 Sources de Données Disponibles

### 1. Google Analytics (GA4)
- **Fichiers :** `ga4_*.csv`
- **Métriques clés :** Trafic, comportement utilisateur, conversions
- **Questions à explorer :**
  - Quelles pages génèrent le plus de leads ?
  - Quel est le parcours utilisateur type ?
  - Quels canaux d'acquisition sont les plus performants ?

### 2. Google Search Console
- **Fichiers :** `search_*.csv`
- **Métriques clés :** Visibilité SEO, mots-clés, positions
- **Questions à explorer :**
  - Sur quels mots-clés Déco Charpente est-elle visible ?
  - Quelles sont les opportunités d'amélioration SEO ?
  - Quel est le potentiel de trafic organique ?

### 3. Pipedrive (CRM)
- **Fichiers :** `leads_*.csv`
- **Métriques clés :** Leads, conversions, cycle de vente
- **Questions à explorer :**
  - Quel est le taux de conversion par source ?
  - Quelle est la durée moyenne du cycle de vente ?
  - Quels concessionnaires performent le mieux ?

### 4. Données Commerciales
- **Fichiers :** `ca_*.csv`
- **Métriques clés :** Chiffre d'affaires, contrats, performance
- **Questions à explorer :**
  - Quelle corrélation entre trafic web et ventes ?
  - Quelles régions ont le plus de potentiel ?
  - Quel est le ROI par canal marketing ?

## 🔍 Analyses Recommandées

### Phase 1 : Diagnostic
1. **Audit du trafic web** (GA4)
2. **Analyse de la visibilité SEO** (Search Console)
3. **Évaluation du pipeline commercial** (Pipedrive)

### Phase 2 : Corrélations
1. **Trafic → Leads** (GA4 + Pipedrive)
2. **SEO → Acquisition** (Search Console + GA4)
3. **Digital → Ventes** (Web + CA)

### Phase 3 : Recommandations
1. **Optimisations techniques** (SEO, UX)
2. **Stratégie d'acquisition** (canaux, budget)
3. **Amélioration du tunnel de conversion**

## 🛠️ Utilisation de l'Application

### Import des Données
1. Aller dans **"Outils"** → **"Analyse CSV"**
2. Glisser-déposer les fichiers CSV
3. Vérifier la validation automatique
4. Explorer les tableaux de bord générés

### Analyses Avancées
1. Utiliser les **graphiques interactifs**
2. Exporter les **résultats d'analyse**
3. Créer des **rapports personnalisés**

### Questions à Poser à l'IA
- "Quels sont les 3 leviers prioritaires pour augmenter les leads ?"
- "Comment améliorer le ROI de Google Ads ?"
- "Quelles pages optimiser en priorité pour le SEO ?"
- "Quelle stratégie pour les concessionnaires sous-performants ?"

## 📈 KPIs à Calculer

### Acquisition
- **Coût d'acquisition client (CAC)** par canal
- **ROI marketing** par source de trafic
- **Taux de conversion** web → lead → client

### Performance
- **Lifetime Value (LTV)** client
- **Durée du cycle de vente**
- **Performance par concessionnaire**

### SEO
- **Visibilité organique** (impressions, positions)
- **Trafic organique qualifié**
- **Potentiel de mots-clés**

## 🎯 Livrables Attendus

1. **Dashboard interactif** avec KPIs principaux
2. **Analyse détaillée** par canal d'acquisition
3. **Recommandations actionnables** (top 5)
4. **Plan d'action** avec priorités et timeline
5. **Présentation** des insights clés

---

💡 **Conseil :** Commencez par explorer les données avec l'IA pour identifier les patterns intéressants, puis creusez les analyses spécifiques !

