# 🎯 Quiz Interactif : Battle des Métriques

## Format du jeu
- **3-4 équipes** de 4-5 personnes
- **Première main levée** répond
- **3 rounds** de difficulté croissante
- **Système de points** : 1-2-3 pts selon la difficulté
- **Bonus justification** : +1 pt si l'équipe explique le "pourquoi"

---

## 🥉 ROUND 1 : Définitions (1 point)

### Question 1
**"Que signifie CTR ?"**
- Réponse : Click-Through Rate (Taux de clic)

### Question 2  
**"Que mesure le ROAS ?"**
- Réponse : Return On Ad Spend (Retour sur investissement publicitaire)

### Question 3
**"CPA signifie ?"**
- Réponse : Cost Per Acquisition (Coût par acquisition)

### Question 4
**"Que veut dire LTV ?"**
- Réponse : Lifetime Value (Valeur vie client)

### Question 5
**"CPM c'est quoi ?"**
- Réponse : Cost Per Mille (Coût pour 1000 impressions)

---

## 🥈 ROUND 2 : Calculs Rapides (2 points)

### Question 1
**"Vous avez 100 000 impressions et 2 000 clics. Quel est votre CTR ?"**
- Réponse : 2% (2000/100000 × 100)

### Question 2
**"Votre CPC est de 0,50€ et vous avez 1000 clics. Quel est votre budget dépensé ?"**
- Réponse : 500€ (0,50 × 1000)

### Question 3
**"Vous dépensez 1000€ en pub et générez 4000€ de CA. Quel est votre ROAS ?"**
- Réponse : 4:1 ou 400% (4000/1000)

### Question 4
**"Vous avez 50 conversions pour 2000 visiteurs. Quel est votre taux de conversion ?"**
- Réponse : 2,5% (50/2000 × 100)

### Question 5
**"Un CPA de 25€ avec 100 acquisitions. Quel est le budget total ?"**
- Réponse : 2500€ (25 × 100)

---

## 🥇 ROUND 3 : Cas Pratiques (3 points)

### Question 1
**"Votre ROAS est de 5:1 mais vos ventes stagnent. Quelle peut être la cause ?"**
- Réponse possible : Budget trop faible, marché saturé, problème de scalabilité des campagnes

### Question 2
**"Un CPA de 25€ est-il bon pour un produit à 50€ de marge ?"**
- Réponse : Oui, car ratio CPA/marge = 50%, ce qui est acceptable

### Question 3
**"Votre CTR chute mais vos conversions restent stables. Que se passe-t-il ?"**
- Réponse possible : Trafic moins qualifié mais mieux ciblé, ou concurrence accrue

### Question 4
**"Comment un taux de rebond élevé peut-il impacter négativement vos campagnes Google Ads ?"**
- Réponse : Diminue le Quality Score, augmente les CPC, réduit les impressions

### Question 5
**"Pourquoi regarder uniquement le ROAS peut être trompeur ?"**
- Réponse : N'indique pas le volume, la profitabilité nette, ou la scalabilité

---

## 🏆 ROUND FINAL : QCM Projeté

### Question 1
**Quel est l'ordre logique du funnel marketing ?**
A) Conversion → Acquisition → Engagement → Rétention  
B) Acquisition → Engagement → Conversion → Rétention ✅  
C) Engagement → Acquisition → Rétention → Conversion  
D) Rétention → Conversion → Acquisition → Engagement

### Question 2
**Un bon taux de conversion e-commerce se situe généralement :**
A) Entre 0,5% et 1%  
B) Entre 1% et 3% ✅  
C) Entre 5% et 10%  
D) Au-dessus de 10%

### Question 3
**Le modèle d'attribution "dernier clic" :**
A) Est le plus précis ✗  
B) Survalorise les canaux de découverte ✗  
C) Sous-estime les canaux de notoriété ✅  
D) Répartit équitablement le crédit ✗

### Question 4
**Pour améliorer son Quality Score Google Ads, il faut optimiser :**
A) Uniquement le CTR ✗  
B) CTR + Pertinence des annonces + Expérience page de destination ✅  
C) Uniquement le budget ✗  
D) Uniquement les mots-clés ✗

### Question 5
**Un ROAS de 2:1 signifie :**
A) 2€ dépensés pour 1€ de CA ✗  
B) 1€ dépensé pour 2€ de CA ✅  
C) 200% de coûts ✗  
D) 50% de rentabilité ✗

---

## 💡 Conseils d'animation

### Dynamisme
- Chronomètre visible (30 secondes par question)
- Musique d'ambiance entre les rounds
- Tableau de scores affiché en permanence
- Encouragements pour toutes les équipes

### Variantes possibles
- **Mode "Buzzer"** : première équipe à frapper dans ses mains
- **Questions flash** : 10 secondes pour répondre
- **Round "mystère"** : question surprise avec double points
- **Penalty** : -1 point pour mauvaise réponse (rend plus stratégique)

### Récompenses suggérées
- 🥇 **1ère place** : "Experts en Data Marketing"
- 🥈 **2ème place** : "Analystes Prometteurs"  
- 🥉 **3ème place** : "Futurs Spécialistes"
- 🎭 **Prix spécial** : "Meilleure justification" pour l'équipe la plus créative
