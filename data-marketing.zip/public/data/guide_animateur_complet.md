# 🎓 Guide Complet de l'Animateur - Formation Data Marketing

## 📋 Vue d'ensemble de la formation

### Durée totale : 6-8 heures (adaptable)
### Participants : 12-24 étudiants (3-6 équipes de 4)
### Matériel requis : 
- Projecteur + écran
- Ordinateurs/tablettes pour les étudiants
- Accès internet
- Tableau/flipchart pour les scores
- Chronomètre

---

## 🎯 Objectifs pédagogiques globaux

À la fin de cette formation, les étudiants seront capables de :
1. **Définir et calculer** les principaux KPIs marketing
2. **Analyser visuellement** des graphiques de performance
3. **Diagnostiquer** des problèmes business à partir de données
4. **Proposer des recommandations** chiffrées et actionnables
5. **Présenter** leurs analyses de façon convaincante

---

## 📊 MODULE 1 : Fondements (45 min)

### Contenu théorique
- Vision stratégique du data marketer
- 3 niveaux : Descriptif → Diagnostique → Prédictif
- Rôle de "traducteur" données → business

### Points clés à souligner
- **Évolution du marketing** : de l'intuition à la preuve
- **Compétences hybrides** : tech + business + communication
- **Impact business direct** : chaque analyse doit mener à une action

### Questions d'engagement (poser à la volée)
- "Qui utilise déjà Google Analytics ?"
- "Donnez-moi un exemple de décision marketing prise sur intuition vs données"
- "Quel est le KPI le plus important selon vous ?"

---

## 📈 MODULE 2 : Métriques du parcours client (60 min)

### Structure recommandée
1. **Présentation théorique** (20 min) : Les 4 étapes du funnel
2. **Exercice pratique** (20 min) : Calculs de KPIs en équipe
3. **Débrief collectif** (20 min) : Correction et insights

### Exercices de calcul à donner

#### Exercice 1 : Campagne Google Ads
**Données :**
- Budget : 1000€
- Impressions : 50 000
- Clics : 1 250
- Conversions : 25
- CA généré : 1 875€

**Questions :**
1. Calculez le CTR
2. Calculez le CPC
3. Calculez le taux de conversion
4. Calculez le CPA
5. Calculez le ROAS
6. Cette campagne est-elle rentable ?

**Réponses :**
1. CTR = 1 250 / 50 000 = 2,5%
2. CPC = 1000€ / 1 250 = 0,80€
3. Taux conversion = 25 / 1 250 = 2%
4. CPA = 1000€ / 25 = 40€
5. ROAS = 1 875€ / 1000€ = 1,875:1
6. **Non rentable** : ROAS < 3:1 généralement problématique

#### Exercice 2 : E-commerce
**Données :**
- Visiteurs mensuels : 10 000
- Commandes : 200
- Panier moyen : 65€
- Marge brute : 40%
- Coût acquisition : 15€/client

**Questions :**
1. Taux de conversion ?
2. CA mensuel ?
3. Marge brute totale ?
4. Coût acquisition total ?
5. Profit net ?

**Réponses :**
1. 200 / 10 000 = 2%
2. 200 × 65€ = 13 000€
3. 13 000€ × 40% = 5 200€
4. 200 × 15€ = 3 000€
5. 5 200€ - 3 000€ = 2 200€

---

## 🔍 MODULE 3 : Sources de données (45 min)

### Cas pratique : L'hôtel "Le Grand Large"

#### Données à projeter
- **GA4 :** Abandon page réservation 85%, Social Media CVR 0,2%
- **Search Console :** "hôtel calme bord de mer" position 4, CTR 1,5%
- **Avis clients :** "Superbe vue, mais très bruyant le soir"
- **CRM :** Familles avec enfants = plus faible taux de re-réservation

#### Questions de débrief
1. "Quel est le problème principal ?"
2. "Comment les 3 sources se connectent-elles ?"
3. "Quelle serait votre première recommandation ?"

#### Réponse type attendue
**Diagnostic :** Dissonance entre promesse ("calme") et réalité (bruit) → Impact SEO, satisfaction, fidélisation des familles

**Recommandations :**
1. Modifier la meta-description pour qualifier le trafic
2. Créer une offre "chambres côté cour" pour familles
3. Optimiser les campagnes Social Media (mauvaise audience)

---

## 🏆 MODULE 4 : Ateliers pratiques (3-4 heures)

### 📊 ATELIER 1 : Analyse visuelle rapide (45 min)

#### Déroulé recommandé
1. **Projection graphiques** (5 min) : Les 4 graphiques s'affichent
2. **Analyse en équipe** (15 min) : Les équipes analysent et notent
3. **Questions interactives** (15 min) : Clic sur questions, première main levée
4. **Synthèse collective** (10 min) : Réponses détaillées

#### Réponses complètes aux questions

**Q1 : Quel jour a la rentabilité la plus faible ?**
- **Réponse :** Dimanche (ROAS 2.3:1)
- **Explication :** Weekend = mode détente, moins d'intention d'achat
- **Action :** Adapter les budgets (moins weekend, plus semaine)

**Q2 : Quel canal a le CPC le plus élevé ?**
- **Réponse :** LinkedIn Ads (3,45€)
- **Explication :** Audience B2B premium, concurrence élevée
- **Action :** Vérifier que la LTV justifie ce coût

**Q3 : Période de baisse de trafic ?**
- **Réponse :** Jours 15-21 (-40%)
- **Explication :** Pause campagnes ? Problème technique ? Concurrent ?
- **Action :** Audit technique + veille concurrentielle

**Q4 : Appareil qui convertit le mieux ?**
- **Réponse :** Tablette (4,2%)
- **Explication :** Hybride desktop/mobile, meilleure UX shopping
- **Action :** Optimiser l'expérience tablette

**Q5 : Pourquoi ROAS plus faible weekend ?**
- **Réponse :** Comportement utilisateur + concurrence différente
- **Explication :** Weekend = loisirs, divertissement vs intention achat
- **Action :** Adapter créas et audiences pour le weekend

**Q6 : Canal avec plus de potentiel ?**
- **Réponse :** TikTok Ads (CPC 0,62€)
- **Explication :** Très bas coût, à condition que le CVR soit decent
- **Action :** Tester scaling avec monitoring CVR

### 🎮 ATELIER 2 : Quiz Battle des métriques (30 min)

#### Organisation des équipes
- **4 équipes max** de 4-5 personnes
- **Noms d'équipe** amusants : Data Ninjas, Analytics Avengers, ROI Warriors, Metric Masters
- **Tableau de scores** visible en permanence

#### Script d'animation

**INTRODUCTION (2 min)**
> "Nous allons maintenant tester vos connaissances dans un quiz compétitif. 3 rounds de difficulté croissante. Première équipe à lever la main répond. Attention, mauvaise réponse = pas de points !"

**ROUND 1 : Définitions (8 min - 6 questions)**

*Exemple de déroulé :*
> "Première question pour 1 point : Que signifie CTR ?"
> *[Équipe lève la main]* "Alpha !"
> "Click-Through Rate !"
> "Exact ! Taux de clic en français. 1 point pour Alpha !"

**Questions supplémentaires Round 1 :**
7. "Que mesure l'AOV ?" → Average Order Value (Valeur panier moyen)
8. "CPL signifie ?" → Cost Per Lead (Coût par prospect)
9. "Que veut dire CR ?" → Conversion Rate (Taux de conversion)
10. "QS dans Google Ads ?" → Quality Score (Note de qualité)

**ROUND 2 : Calculs (10 min - 6 questions)**

*Conseil animation :*
> "Vous avez 30 secondes pour calculer. Les calculatrices sont autorisées !"

**Questions supplémentaires Round 2 :**
7. "ROAS de 300% = ratio ?" → 3:1
8. "Marge 60€, CPA 20€. Rentable ?" → Oui, ratio 33%
9. "CTR 1,5%, 80k impressions. Clics ?" → 1 200
10. "Budget 500€, CPC 0,25€. Clics max ?" → 2 000

**ROUND 3 : Cas pratiques (10 min - 5 questions)**

*Questions supplémentaires :*
6. "Comment améliorer un Quality Score faible ?" → Optimiser CTR + pertinence annonces + landing page
7. "ROAS stable mais CA baisse. Cause ?" → Diminution du budget ou du volume de trafic
8. "Forte saisonnalité : comment ajuster les budgets ?" → Allocation dynamique selon performances historiques

#### Récompenses suggérées
- **🥇 1ère place :** "Data Marketing Champions"
- **🥈 2ème place :** "Future Analytics Experts" 
- **🥉 3ème place :** "Promising Data Analysts"
- **🎭 Prix spécial :** "Most Creative Explanation"

### 🎭 ATELIER 3 : Scénarios business (60 min)

#### Déroulé détaillé

**PHASE 1 : Tirage et analyse (20 min)**
- Chaque équipe tire un scénario
- Lecture individuelle (5 min)
- Analyse en équipe (15 min)

**PHASE 2 : Préparation pitch (10 min)**
- Structurer la présentation
- Répartir les rôles de présentation
- Préparer 1 slide si possible

**PHASE 3 : Présentations (25 min)**
- 3 min par équipe + 1 min questions
- Timer visible
- Notes sur grille d'évaluation

**PHASE 4 : Vote et débriefs (5 min)**
- Vote à main levée (pas sa propre équipe)
- Annonce du gagnant
- Points forts de chaque présentation

#### Questions de débrief par scénario

**FitTracker (App Fitness) :**
- "Pourquoi 70% abandonnent en 7 jours ?"
- "Comment mesurer le succès d'un nouvel onboarding ?"
- "Quel est le coût d'un churn évité ?"

**StyleCo (E-commerce Mode) :**
- "Pourquoi 80% n'achètent qu'un article ?"
- "Comment tester l'efficacité du cross-sell ?"
- "Quel impact des retours sur la confiance ?"

**ImmoPlus (Immobilier) :**
- "Pourquoi le SEO local est crucial en immobilier ?"
- "Comment mesurer la qualité d'un lead ?"
- "Quelle saisonnalité en immobilier ?"

#### Grille d'évaluation détaillée

| Critère | Excellent (5) | Bon (4) | Moyen (3) | Faible (2) | Absent (1) |
|---------|---------------|---------|-----------|------------|------------|
| **Pertinence business** | Solution répond parfaitement au problème | Solution répond bien | Solution partiellement adaptée | Solution peu pertinente | Hors sujet |
| **Faisabilité** | Totalement réalisable avec contraintes | Globalement réalisable | Moyennement réalisable | Difficilement réalisable | Irréalisable |
| **Créativité** | Approche très innovante | Approche originale | Quelques idées créatives | Peu d'originalité | Approche banale |
| **Méthodologie** | KPIs parfaitement définis | KPIs bien définis | KPIs partiellement définis | KPIs flous | Pas de KPIs |
| **ROI prévisible** | ROI clairement calculé et crédible | ROI estimé de façon réaliste | ROI approximatif | ROI peu crédible | Pas de ROI |

---

## 🎤 Conseils d'animation généraux

### Gestion du timing
- **Timer visible** pour tous les exercices
- **Alertes 5 min, 2 min, 30 sec** avant la fin
- **Flexibilité** : adapter selon l'engagement du groupe

### Maintenir l'engagement
- **Circuler** entre les équipes pendant les exercices
- **Poser des questions** : "Comment ça se passe ici ?"
- **Encourager** toutes les équipes, pas seulement les premières

### Gestion des questions difficiles
- **Renvoyer au groupe** : "Quelqu'un a une idée ?"
- **Décomposer** : "Commençons par définir le CTR"
- **Utiliser l'erreur** : "Bonne tentative ! Qui peut corriger ?"

### Débriefs efficaces
- **Commencer par les positifs** : "Très bonne analyse de..."
- **Synthétiser** les points clés
- **Faire le lien** avec la pratique professionnelle

---

## 📝 Évaluation et suivi

### Critères d'évaluation continue
- **Participation** aux discussions (20%)
- **Qualité des analyses** dans les exercices (30%)
- **Travail d'équipe** et collaboration (20%)
- **Présentation finale** et communication (30%)

### Feedback aux étudiants
- **Points forts** observés pendant la session
- **Axes d'amélioration** pour le développement professionnel
- **Ressources** pour approfondir (sites, outils, certifications)

### Auto-évaluation formateur
- Quels exercices ont le mieux fonctionné ?
- Où les étudiants ont-ils eu des difficultés ?
- Quel timing ajuster pour la prochaine session ?

---

## 🔗 Ressources complémentaires

### Pour approfondir
- **Google Analytics Academy** (certification gratuite)
- **Google Ads Skillshop** (certification officielle)
- **Facebook Blueprint** (formation Meta Ads)
- **DataCamp** (formation data analysis)

### Outils recommandés
- **Tableau Public** (visualisation gratuite)
- **Google Data Studio** (dashboards gratuits)
- **Excel/Google Sheets** (analyses de base)
- **Canva** (présentations visuelles)

### Veille professionnelle
- **Blog Google Analytics** (updates produit)
- **Search Engine Land** (actualités SEA/SEO)
- **Marketing Land** (tendances marketing digital)
- **LinkedIn Learning** (formations continues)

---

## ✅ Checklist de préparation

### Avant la session
- [ ] Tester tous les liens et outils
- [ ] Préparer les équipes (noms, couleurs)
- [ ] Vérifier le matériel (projecteur, internet)
- [ ] Préparer les supports de notation
- [ ] Prévoir les récompenses/certificats

### Pendant la session
- [ ] Alterner théorie/pratique toutes les 20 min
- [ ] Maintenir l'énergie avec des questions
- [ ] Noter les points saillants pour le debrief
- [ ] Adapter le rythme selon l'engagement
- [ ] Encourager la participation de tous

### Après la session
- [ ] Recueillir les feedbacks étudiants
- [ ] Noter les améliorations pour la prochaine fois
- [ ] Partager les ressources complémentaires
- [ ] Planifier le suivi pédagogique

---

*Ce guide vous donne tous les éléments pour animer une formation data marketing dynamique et professionnalisante. Adaptez le contenu selon votre public et vos contraintes de temps !* 🚀
