# Guide d'analyse : Données SEO Déco Charpente

## 📊 Vue d'ensemble des données

Ce guide accompagne l'analyse des données de rank-tracker.csv pour l'entreprise Déco Charpente, spécialisée dans les abris en bois sur mesure.

### Données analysées
- **Source** : rank-tracker.csv (484 mots-clés suivis)
- **Période** : Données de suivi de positions Google
- **Entreprise** : Déco Charpente (construction d'abris en bois)
- **Secteur** : BTP / Construction bois / Aménagement extérieur

## 🎯 Objectifs pédagogiques

1. **Comprendre les métriques SEO** : Position, visibilité, tendances
2. **Analyser les performances** : Identifier les forces et faiblesses
3. **Formuler des recommandations** : Proposer des actions d'amélioration
4. **Interpréter les corrélations** : Position vs visibilité vs volume de recherche

## 📈 Insights clés identifiés

### 1. Performances par catégorie de mots-clés

#### ✅ Mots-clés performants (positions 1-6)
- **"abri voitures"** : Position 1, Visibilité 0.42
- **"abri voiture bois fermé"** : Position 4, Visibilité 0.77
- **"carport en bois"** : Position 4, Visibilité 0.1
- **"abri voiture"** : Position 6, Visibilité 0.52

**Analyse** : Ces termes correspondent au cœur de métier et bénéficient d'une optimisation SEO efficace.

#### ⚠️ Mots-clés à améliorer (positions 11+)
- **"pool house bois"** : Position 14, Visibilité 0.28
- **"abri voiture en bois"** : Position 16, Visibilité 0.15
- **"abris voiture bois"** : Position 11, Visibilité 0.38

**Analyse** : Potentiel commercial élevé mais optimisation SEO insuffisante.

### 2. Corrélation Position vs Visibilité

#### Observations importantes :
- La visibilité ne suit pas toujours la position
- "abri voiture bois fermé" (pos. 4) a une visibilité de 0.77
- "carport en bois" (pos. 4) n'a qu'une visibilité de 0.1

**Explication** : La visibilité dépend du volume de recherche du mot-clé et de la concurrence.

### 3. Distribution des performances

- **30%** des mots-clés dans le top 6 (excellent/très bon)
- **20%** en positions 7-10 (bon)
- **40%** au-delà de la position 10 (à améliorer)
- **10%** non classés ou déclassés

## 🔑 Clés de réponse aux exercices

### Question 1 : Mots-clés les mieux positionnés
**Réponse** : 
1. "abri voitures" (pos. 1) - Terme générique du cœur de métier
2. "abri voiture bois fermé" (pos. 4) - Spécialisation technique
3. "carport en bois" (pos. 4) - Terme alternatif populaire

**Pourquoi ils performent** :
- Correspondance exacte avec l'offre de Déco Charpente
- Contenu optimisé et autorité thématique
- Maillage interne efficace
- Backlinks de qualité dans le secteur

### Question 2 : Corrélation position-visibilité
**Analyse** :
- Corrélation imparfaite due aux volumes de recherche différents
- Les mots-clés spécialisés peuvent avoir une forte visibilité même en position moyenne
- La concurrence influence la visibilité plus que la position absolue

### Question 3 : Recommandations d'amélioration
**Pour les mots-clés sous-performants** :
1. **Optimisation on-page** : Balises title, meta descriptions, H1-H6
2. **Contenu de qualité** : Articles de blog, guides techniques, FAQ
3. **Maillage interne** : Liens contextuels vers les pages cibles
4. **Link building** : Partenariats avec des sites du secteur BTP
5. **Optimisation technique** : Vitesse, mobile-first, structure des données

### Question 4 : Mots-clés génériques vs spécifiques
**Explication** :
- Les termes génériques ("abri voiture") sont plus concurrentiels
- Les termes spécifiques ("abri voiture bois fermé") ont moins de concurrence
- La spécialisation correspond mieux à l'expertise de Déco Charpente
- Stratégie de niche plus efficace que la généralisation

## 📋 Méthodologie d'analyse appliquée

### 1. Collecte et préparation des données
- Extraction des colonnes pertinentes du CSV
- Nettoyage des données (positions, visibilité)
- Catégorisation des performances

### 2. Analyse exploratoire
- Distribution des positions
- Corrélations entre métriques
- Identification des outliers

### 3. Visualisation
- Graphique scatter position vs visibilité
- Histogramme de distribution des positions
- Codage couleur par performance

### 4. Interprétation et recommandations
- Identification des patterns
- Formulation d'hypothèses
- Propositions d'actions concrètes

## 🎓 Compétences développées

À travers cet exercice, les étudiants développent :

1. **Analyse de données SEO** : Comprendre les métriques de rank tracking
2. **Pensée critique** : Interpréter les corrélations et causalités
3. **Visualisation de données** : Créer des graphiques pertinents
4. **Recommandations stratégiques** : Formuler des actions concrètes
5. **Compréhension business** : Lier les données aux objectifs commerciaux

## 📚 Pour aller plus loin

### Analyses complémentaires possibles :
- Évolution temporelle des positions
- Analyse de la concurrence
- Corrélation avec le trafic organique
- Impact des actions SEO sur les positions
- Analyse saisonnière des performances

### Outils recommandés :
- Google Search Console
- SEMrush / Ahrefs pour la concurrence
- Google Analytics pour le trafic
- Screaming Frog pour l'audit technique

---

*Ce guide accompagne l'exercice pratique d'analyse de données SEO dans le cadre de la formation en Data Marketing.*

