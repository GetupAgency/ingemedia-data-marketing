# 🎭 Atelier Scénarios : Que Feriez-Vous ?

## Format de l'exercice
- **6 scénarios** d'entreprises réelles
- **15 minutes** d'analyse par équipe
- **3 minutes** de pitch par équipe
- **Vote collectif** pour la meilleure solution

---

## 📱 SCÉNARIO 1 : App Mobile Fitness

### Contexte
**FitTracker** - Application de suivi sportif  
- 50k utilisateurs actifs mensuels
- 30% de churn mensuel (trop élevé !)
- Budget disponible : 10k€
- Objectif : Réduire le churn à 15% en 3 mois

### Données disponibles
- 70% utilisent l'app < 7 jours après téléchargement
- Pic d'abandon après la 1ère séance d'entraînement
- Users qui complètent l'onboarding : churn de 12%
- Notifications push : taux d'ouverture 8%

### Votre mission
Proposez 3 actions concrètes avec budget alloué et KPIs de mesure.

---

## 👗 SCÉNARIO 2 : E-commerce Mode Féminine

### Contexte
**StyleCo** - Boutique en ligne de vêtements  
- Panier moyen : 45€ (concurrent : 65€)
- Taux de conversion : 1,2%
- Budget disponible : 15k€
- Objectif : Augmenter le panier moyen de 30%

### Données disponibles
- 80% des ventes = 1 seul article
- Taux d'abandon panier : 85%
- Page produit : temps moyen 45 secondes
- Retours produits : 25% (vs 15% secteur)

### Votre mission
Comment augmenter la valeur panier tout en réduisant les retours ?

---

## 🏠 SCÉNARIO 3 : Agence Immobilière Locale

### Contexte
**ImmoPlus** - Agence traditionnelle qui se digitalise  
- Zone : Métropole de 200k habitants
- 5 concurrents directs
- Budget : 8k€
- Objectif : Générer 50 leads qualifiés/mois

### Données disponibles
- Site actuel : 500 visiteurs/mois
- Taux de conversion contact : 2%
- 60% du trafic = recherche "immobilier [ville]"
- Présence locale faible sur Google Maps

### Votre mission
Quelle stratégie digitale pour dominer le marché local ?

---

## 💻 SCÉNARIO 4 : Startup SaaS B2B

### Contexte
**DataSync** - Logiciel de synchronisation de données  
- Freemium model (version gratuite + premium 50€/mois)
- 2000 utilisateurs gratuits
- Conversion freemium → premium : 3%
- Budget : 20k€

### Données disponibles
- 70% utilisent < 20% des fonctionnalités
- Support client : 40% des questions = "Comment faire X ?"
- Users premium utilisent 80% des fonctionnalités
- Churn premium : 5%/mois

### Votre mission
Comment doubler le taux de conversion freemium → premium ?

---

## 🍕 SCÉNARIO 5 : Restaurant/Livraison

### Contexte
**PizzaRapido** - Pizzeria avec livraison  
- Zone de livraison : 10km
- 150 commandes/semaine
- Panier moyen : 18€
- Budget : 5k€
- Objectif : +50% de commandes en 2 mois

### Données disponibles
- 90% commandes = clients récurrents
- Pic de commandes : vendredi-samedi 19h-21h
- Temps de livraison moyen : 35 min
- 2 concurrents avec app mobile

### Votre mission
Comment acquérir massivement de nouveaux clients ?

---

## 📚 SCÉNARIO 6 : Formation en Ligne

### Contexte
**LearnFast** - Plateforme de cours en ligne  
- 500 cours disponibles
- Prix moyen : 80€/cours
- Taux de complétion : 25% (très faible !)
- Budget : 12k€

### Données disponibles
- 60% abandonnent avant le module 3
- Cours avec quiz interactifs : 45% complétion
- Users qui complètent = 90% de satisfaction
- Certificats = 40% de valeur perçue en plus

### Votre mission
Comment tripler le taux de complétion des cours ?

---

## 🎯 Grille d'évaluation pour les équipes

### Critères (sur 5 points chacun)
1. **Pertinence business** : La solution répond-elle vraiment au problème ?
2. **Faisabilité** : Est-ce réalisable avec le budget et délais donnés ?
3. **Créativité** : Y a-t-il des idées originales et innovantes ?
4. **Méthodologie** : Les KPIs de mesure sont-ils bien définis ?
5. **ROI prévisible** : Le retour sur investissement est-il crédible ?

### Questions bonus (+1 point)
- Avez-vous identifié un risque principal et sa mitigation ?
- Proposez-vous un test pilote avant déploiement complet ?
- Y a-t-il une approche data-driven pour valider les hypothèses ?

---

## 💡 Solutions suggérées (guide formateur)

### Scénario 1 - App Fitness
**Problème principal** : Onboarding défaillant
**Actions** : 
- Refonte UX onboarding (5k€)
- Coaching IA premier mois (3k€)
- Push notifications personnalisées (2k€)

### Scénario 2 - E-commerce Mode
**Problème principal** : Manque de cross-sell/up-sell
**Actions** :
- Recommandations IA (8k€)
- "Complétez votre look" (4k€)
- Frais de port gratuits dès 60€ (3k€)

### Scénario 3 - Immobilier
**Problème principal** : Visibilité locale insuffisante
**Actions** :
- SEO local + Google My Business (3k€)
- Campagnes Facebook géociblées (4k€)
- Contenu hyperlocal (1k€)

### Scénario 4 - SaaS
**Problème principal** : Adoption produit insuffisante
**Actions** :
- Onboarding guidé (10k€)
- Webinaires démonstration (5k€)
- Notifications usage produit (5k€)

### Scénario 5 - Restaurant
**Problème principal** : Acquisition limitée au bouche-à-oreille
**Actions** :
- App mobile + parrainage (3k€)
- Partenariats influenceurs locaux (1k€)
- Programme de fidélité (1k€)

### Scénario 6 - Formation
**Problème principal** : Engagement utilisateur faible
**Actions** :
- Gamification parcours (6k€)
- Communauté étudiants (3k€)
- Micro-learning adaptatif (3k€)
