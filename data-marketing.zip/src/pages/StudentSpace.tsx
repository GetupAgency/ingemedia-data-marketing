import React, { useEffect, useRef, useState } from 'react';
import Chart from 'chart.js/auto';

/**
 * Espace Étudiant - Zone de travail personnelle pour les étudiants
 */
const StudentSpace: React.FC = () => {
  const roasChartRef = useRef<HTMLCanvasElement>(null);
  const cpaChartRef = useRef<HTMLCanvasElement>(null);
  const chartInstances = useRef<Chart[]>([]);
  const [csvData, setCsvData] = useState<any[]>([]);

  useEffect(() => {
    // Charger les données CSV
    const loadCSVData = async () => {
      try {
        const response = await fetch('/data/marketing_performance_data.csv');
        const text = await response.text();
        const lines = text.split('\n').slice(1); // Ignorer l'en-tête
        
        const data = lines.filter(line => line.trim()).map(line => {
          const values = line.split(',');
          return {
            date: values[0],
            canal: values[1],
            campagne: values[2],
            impressions: parseInt(values[3]),
            clics: parseInt(values[4]),
            cout: parseFloat(values[5]),
            conversions: parseInt(values[6]),
            ca: parseFloat(values[7]),
            appareil: values[8],
            age: values[9],
            genre: values[10]
          };
        });
        
        setCsvData(data);
      } catch (error) {
        console.error('Erreur lors du chargement des données CSV:', error);
      }
    };

    loadCSVData();
  }, []);

  useEffect(() => {
    if (csvData.length === 0) return;

    // Nettoyer les graphiques existants
    chartInstances.current.forEach(chart => chart.destroy());
    chartInstances.current = [];

    // Calculer ROAS par canal
    const roasByChannel = csvData.reduce((acc: any, row) => {
      if (!acc[row.canal]) {
        acc[row.canal] = { totalCA: 0, totalCout: 0 };
      }
      acc[row.canal].totalCA += row.ca;
      acc[row.canal].totalCout += row.cout;
      return acc;
    }, {});

    const roasData = Object.entries(roasByChannel).map(([canal, data]: [string, any]) => ({
      canal,
      roas: data.totalCA / data.totalCout
    }));

    // Calculer CPA par canal
    const cpaByChannel = csvData.reduce((acc: any, row) => {
      if (!acc[row.canal]) {
        acc[row.canal] = { totalCout: 0, totalConversions: 0 };
      }
      acc[row.canal].totalCout += row.cout;
      acc[row.canal].totalConversions += row.conversions;
      return acc;
    }, {});

    const cpaData = Object.entries(cpaByChannel).map(([canal, data]: [string, any]) => ({
      canal,
      cpa: data.totalCout / data.totalConversions
    }));

    // Créer le graphique ROAS
    if (roasChartRef.current) {
      const roasChart = new Chart(roasChartRef.current, {
        type: 'bar',
        data: {
          labels: roasData.map(d => d.canal),
          datasets: [{
            label: 'ROAS',
            data: roasData.map(d => d.roas),
            backgroundColor: ['#3b82f6', '#8b5cf6'],
            borderRadius: 4
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { 
            legend: { display: false },
            title: { display: true, text: 'ROAS par Canal Marketing' }
          },
          scales: {
            y: { 
              beginAtZero: true,
              title: { display: true, text: 'ROAS (Ratio)' }
            }
          }
        }
      });
      chartInstances.current.push(roasChart);
    }

    // Créer le graphique CPA
    if (cpaChartRef.current) {
      const cpaChart = new Chart(cpaChartRef.current, {
        type: 'bar',
        data: {
          labels: cpaData.map(d => d.canal),
          datasets: [{
            label: 'CPA (€)',
            data: cpaData.map(d => d.cpa),
            backgroundColor: ['#10b981', '#f59e0b'],
            borderRadius: 4
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { 
            legend: { display: false },
            title: { display: true, text: 'Coût par Acquisition (CPA) par Canal' }
          },
          scales: {
            y: { 
              beginAtZero: true,
              title: { display: true, text: 'CPA (€)' }
            }
          }
        }
      });
      chartInstances.current.push(cpaChart);
    }

    return () => {
      chartInstances.current.forEach(chart => chart.destroy());
    };
  }, [csvData]);

  return (
    <div className="min-h-screen bg-gray-50 pt-24 pb-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* En-tête simplifié */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">
            Analyse Data Marketing - Déco Charpente
          </h1>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Analysez les données marketing de Déco Charpente et créez des tableaux de bord avec l'IA
          </p>
        </div>

        {/* Instructions simplifiées */}
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-6 mb-8">
          <h2 className="text-xl font-bold text-blue-900 mb-3">
            📊 Votre Mission d'Analyse
          </h2>
          <p className="text-blue-800 mb-4 leading-relaxed">
            Vous avez accès aux données marketing complètes de <strong>Déco Charpente</strong> : Google Ads, Meta Ads, 
            Search Console, et Google Analytics. Votre objectif est d'analyser ces données et de créer des 
            recommandations actionnables pour optimiser leur stratégie digitale.
          </p>
          
          <div className="bg-white border border-blue-200 rounded-lg p-4">
            <h3 className="font-semibold text-blue-900 mb-2">💬 Comment poser vos questions à l'IA :</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm text-blue-800">
              <div>
                <p className="font-medium mb-1">Questions d'analyse :</p>
                <ul className="text-xs space-y-1">
                  <li>• "Analyse les performances Google Ads de Déco Charpente"</li>
                  <li>• "Quel canal génère le meilleur ROI ?"</li>
                  <li>• "Quels mots-clés SEO optimiser en priorité ?"</li>
                </ul>
              </div>
              <div>
                <p className="font-medium mb-1">Demandes de visualisation :</p>
                <ul className="text-xs space-y-1">
                  <li>• "Crée un graphique des conversions par campagne"</li>
                  <li>• "Montre-moi l'évolution du trafic sur l'année"</li>
                  <li>• "Compare les performances par concessionnaire"</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Sources de données disponibles */}
        <div className="bg-white border border-slate-200 rounded-xl p-6 mb-8">
          <h2 className="text-xl font-bold text-slate-900 mb-4">📁 Sources de Données Disponibles</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
              <h3 className="font-semibold text-blue-900 mb-2">🎯 Google Ads</h3>
              <div className="text-xs text-blue-800 space-y-1">
                <div>• Campagnes par concessionnaire</div>
                <div>• Termes de recherche (63k+)</div>
                <div>• Performance temporelle</div>
                <div>• Budget: ~40k€</div>
              </div>
            </div>
            
            <div className="bg-green-50 p-4 rounded-lg border border-green-200">
              <h3 className="font-semibold text-green-900 mb-2">📱 Meta Ads</h3>
              <div className="text-xs text-green-800 space-y-1">
                <div>• Campagnes lead generation</div>
                <div>• Performance créatifs</div>
                <div>• Audiences et reach</div>
                <div>• Budget: ~2.5k€</div>
              </div>
            </div>
            
            <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
              <h3 className="font-semibold text-purple-900 mb-2">🔍 Search Console</h3>
              <div className="text-xs text-purple-800 space-y-1">
                <div>• 1000+ mots-clés</div>
                <div>• Performance pages</div>
                <div>• Positions & CTR</div>
                <div>• SEO local</div>
              </div>
            </div>
            
            <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
              <h3 className="font-semibold text-orange-900 mb-2">📊 Analytics</h3>
              <div className="text-xs text-orange-800 space-y-1">
                <div>• Trafic hebdomadaire</div>
                <div>• Saisonnalité business</div>
                <div>• Acquisition channels</div>
                <div>• 1 an de données</div>
              </div>
            </div>
            
            <div className="bg-red-50 p-4 rounded-lg border border-red-200">
              <h3 className="font-semibold text-red-900 mb-2">💼 Pipedrive CRM</h3>
              <div className="text-xs text-red-800 space-y-1">
                <div>• 7,479 deals (7+ ans)</div>
                <div>• Cycle de vente complet</div>
                <div>• ROI réel mesurable</div>
                <div>• 6 concessionnaires</div>
              </div>
            </div>
            
            <div className="bg-teal-50 p-4 rounded-lg border border-teal-200">
              <h3 className="font-semibold text-teal-900 mb-2">📈 RankTracker</h3>
              <div className="text-xs text-teal-800 space-y-1">
                <div>• 484 mots-clés suivis</div>
                <div>• Positions exactes</div>
                <div>• Évolution tendances</div>
                <div>• SEO local avancé</div>
              </div>
            </div>
          </div>
        </div>

        {/* Zone de travail principale */}
        <div className="bg-gradient-to-r from-indigo-50 to-blue-50 border-2 border-dashed border-indigo-300 rounded-xl p-8 text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold text-indigo-900 mb-4">
              🚀 Votre Espace d'Analyse
            </h2>
            <p className="text-indigo-800 mb-6 leading-relaxed">
              Toutes les données de Déco Charpente sont chargées et prêtes à être analysées. 
              Posez vos questions à l'IA pour créer des graphiques, identifier des insights, 
              et développer des recommandations stratégiques.
            </p>
            
            <div className="bg-white border border-indigo-200 rounded-lg p-6 text-left mb-6">
              <h3 className="font-semibold text-indigo-900 mb-3">💡 Exemples de questions à poser :</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-indigo-800">
                <div>
                  <p className="font-medium mb-2">Analyses ROI & Performance :</p>
                  <ul className="space-y-1 text-xs">
                    <li>• "Quel est le ROI réel de Google Ads vs Meta Ads ?"</li>
                    <li>• "Corrélation entre dépenses pub et ventes Pipedrive ?"</li>
                    <li>• "Quels concessionnaires ont le meilleur taux de conversion ?"</li>
                    <li>• "Impact des positions SEO sur les leads ?"</li>
                  </ul>
                </div>
                <div>
                  <p className="font-medium mb-2">Dashboards & Visualisations :</p>
                  <ul className="space-y-1 text-xs">
                    <li>• "Crée un dashboard du cycle complet lead → vente"</li>
                    <li>• "Montre l'évolution des positions SEO vs trafic"</li>
                    <li>• "Analyse la saisonnalité cross-canal"</li>
                    <li>• "Compare la performance par concessionnaire"</li>
                  </ul>
                </div>
              </div>
            </div>
            
            <div className="bg-gradient-to-r from-green-100 to-emerald-100 border border-green-300 rounded-lg p-4">
              <p className="text-sm text-green-800">
                <strong>💬 Pour commencer :</strong> Tapez votre question dans le chat Cursor. 
                L'IA a accès à toutes les données dans le dossier <code className="bg-green-200 px-1 rounded">/data</code> 
                et peut créer des analyses personnalisées en temps réel !
              </p>
            </div>
            
            <div className="mt-4 bg-blue-100 border border-blue-300 rounded-lg p-3">
              <p className="text-xs text-blue-800">
                <strong>📁 Astuce :</strong> Tous les fichiers sont dans <code>/data</code> - 
                consultez le <code>README.md</code> pour vous orienter !
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentSpace;
