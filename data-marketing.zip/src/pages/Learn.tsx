import React, { useState } from 'react';
import DataMarketingCourse from '../components/DataMarketingCourse';
import QuizSessionHistory from '../components/QuizSessionHistory';

/**
 * Page Apprendre
 * 
 * Cette page présente des ressources éducatives sur le data marketing,
 * incluant une formation intensive complète.
 */
const Learn: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'overview' | 'course' | 'resources' | 'sessions'>('overview');

  return (
    <div className="min-h-screen bg-gray-50 pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* En-tête */}
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Ressources d'apprentissage</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Découvrez nos ressources pour approfondir vos connaissances en data marketing.
          </p>
        </div>
        
        {/* Navigation par onglets */}
        <div className="mb-8">
          <nav className="flex space-x-8 justify-center" aria-label="Tabs">
            <button
              onClick={() => setActiveTab('overview')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'overview'
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Vue d'ensemble
            </button>
            <button
              onClick={() => setActiveTab('course')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'course'
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Formation Intensive
            </button>
            <button
              onClick={() => setActiveTab('resources')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'resources'
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Ressources
            </button>
            <button
              onClick={() => setActiveTab('sessions')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'sessions'
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Résultats Quiz
            </button>
          </nav>
        </div>

        {/* Contenu des onglets */}
        {activeTab === 'overview' && (
          <div className="space-y-12">
            {/* Hero section moderne */}
            <div className="text-center bg-gradient-to-br from-slate-50 to-indigo-50 border border-slate-200 rounded-2xl p-12">
              <h2 className="text-3xl font-bold text-slate-900 mb-4">
                Maîtrisez le data marketing moderne
              </h2>
              <p className="text-lg text-slate-600 mb-8 max-w-3xl mx-auto leading-relaxed">
                Formation complète et interactive pour transformer les données en décisions business actionnables. 
                De la théorie aux outils professionnels, développez les compétences recherchées par les entreprises.
              </p>
              <button 
                onClick={() => setActiveTab('course')}
                className="bg-indigo-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-indigo-700 transition-all duration-200 shadow-lg hover:shadow-xl"
              >
                Commencer la formation
              </button>
            </div>

            {/* Parcours d'apprentissage */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div 
                onClick={() => setActiveTab('course')}
                className="group bg-white border border-slate-200 rounded-xl p-8 hover:shadow-lg transition-all duration-200 cursor-pointer hover:border-indigo-300"
              >
                <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-6 group-hover:bg-indigo-200 transition-colors">
                  <svg className="w-6 h-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C20.332 18.477 18.747 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                  </svg>
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-3">Formation intensive</h3>
                <p className="text-slate-600 text-sm mb-4 leading-relaxed">
                  5 modules progressifs avec exercices interactifs, quiz Battle et scénarios business réels. 
                  Support de cours consultable à vie.
                </p>
                <div className="flex items-center text-indigo-600 text-sm font-medium">
                  <span>Découvrir la formation</span>
                  <svg className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                  </svg>
                </div>
              </div>

              <a 
                href="/tutorials" 
                className="group bg-white border border-slate-200 rounded-xl p-8 hover:shadow-lg transition-all duration-200 hover:border-green-300"
              >
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-6 group-hover:bg-green-200 transition-colors">
                  <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                  </svg>
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-3">Tutoriels pratiques</h3>
                <p className="text-slate-600 text-sm mb-4 leading-relaxed">
                  Guides détaillés step-by-step pour maîtriser les outils. 
                  Manipulation directe de Google Analytics, CSV et dashboards.
                </p>
                <div className="flex items-center text-green-600 text-sm font-medium">
                  <span>Explorer les tutoriels</span>
                  <svg className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                  </svg>
                </div>
              </a>

              <a 
                href="/quizzes" 
                className="group bg-white border border-slate-200 rounded-xl p-8 hover:shadow-lg transition-all duration-200 hover:border-orange-300"
              >
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-6 group-hover:bg-orange-200 transition-colors">
                  <svg className="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-3">Quiz adaptatifs</h3>
                <p className="text-slate-600 text-sm mb-4 leading-relaxed">
                  3 quiz avec 58 questions alignées sur le cours. 
                  Progression du débutant à l'intermédiaire avec feedback personnalisé.
                </p>
                <div className="flex items-center text-orange-600 text-sm font-medium">
                  <span>Tester vos acquis</span>
                  <svg className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
            </svg>
                </div>
              </a>
            </div>

            {/* Statistiques et métriques */}
            <div className="bg-white border border-slate-200 rounded-xl p-8">
              <h2 className="text-2xl font-bold text-slate-900 mb-8 text-center">Votre parcours d'apprentissage</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <div className="text-center p-6 bg-slate-50 rounded-lg">
                  <div className="text-3xl font-bold text-indigo-600 mb-2">5</div>
                  <div className="text-sm text-slate-600">Modules de formation</div>
                </div>
                <div className="text-center p-6 bg-slate-50 rounded-lg">
                  <div className="text-3xl font-bold text-green-600 mb-2">6</div>
                  <div className="text-sm text-slate-600">Exercices interactifs</div>
                </div>
                <div className="text-center p-6 bg-slate-50 rounded-lg">
                  <div className="text-3xl font-bold text-orange-600 mb-2">58</div>
                  <div className="text-sm text-slate-600">Questions de quiz</div>
                </div>
                <div className="text-center p-6 bg-slate-50 rounded-lg">
                  <div className="text-3xl font-bold text-purple-600 mb-2">17</div>
                  <div className="text-sm text-slate-600">Outils présentés</div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <h3 className="font-semibold text-slate-900 mb-2">Niveau débutant</h3>
                  <p className="text-sm text-slate-600">Fondements, KPIs essentiels, calculs de base</p>
                </div>
                <div className="text-center">
                  <h3 className="font-semibold text-slate-900 mb-2">Niveau intermédiaire</h3>
                  <p className="text-sm text-slate-600">Attribution, optimisation, analyses avancées</p>
                </div>
                <div className="text-center">
                  <h3 className="font-semibold text-slate-900 mb-2">Application pratique</h3>
                  <p className="text-sm text-slate-600">Cas d'entreprise, outils professionnels</p>
                </div>
              </div>
            </div>

            {/* Section compétences développées */}
            <div className="bg-gradient-to-r from-indigo-50 to-slate-50 border border-indigo-200 rounded-xl p-8">
              <h2 className="text-2xl font-bold text-slate-900 mb-8 text-center">Compétences développées</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <h3 className="font-semibold text-slate-900 mb-4">Compétences techniques</h3>
                  <div className="space-y-3">
                    <div className="flex items-center text-sm">
                      <div className="w-2 h-2 bg-indigo-500 rounded-full mr-3"></div>
                      <span className="text-slate-700">Analyse de données marketing multi-sources</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <div className="w-2 h-2 bg-indigo-500 rounded-full mr-3"></div>
                      <span className="text-slate-700">Calcul et interprétation des KPIs</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <div className="w-2 h-2 bg-indigo-500 rounded-full mr-3"></div>
                      <span className="text-slate-700">Maîtrise de Google Analytics et Search Console</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <div className="w-2 h-2 bg-indigo-500 rounded-full mr-3"></div>
                      <span className="text-slate-700">Création de dashboards et reporting</span>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h3 className="font-semibold text-slate-900 mb-4">Compétences business</h3>
                  <div className="space-y-3">
                    <div className="flex items-center text-sm">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                      <span className="text-slate-700">Diagnostic de performance marketing</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                      <span className="text-slate-700">Recommandations stratégiques chiffrées</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                      <span className="text-slate-700">Optimisation ROI et allocation budgets</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                      <span className="text-slate-700">Présentation de résultats (data storytelling)</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'course' && (
          <DataMarketingCourse />
        )}

        {activeTab === 'resources' && (
          <div className="space-y-8">
            <div className="bg-white border border-slate-200 rounded-xl p-8">
              <h2 className="text-2xl font-bold text-slate-900 mb-8 text-center">Ressources complémentaires</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <a 
                  href="/glossary" 
                  className="group p-6 border border-slate-200 rounded-lg hover:shadow-md transition-all duration-200 hover:border-indigo-300"
                >
                  <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-indigo-200 transition-colors">
                    <svg className="w-6 h-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C20.332 18.477 18.747 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 mb-3">Lexique data marketing</h3>
                  <p className="text-slate-600 text-sm mb-4 leading-relaxed">
                    Glossaire complet des termes et acronymes du data marketing. 
                    Définitions claires avec exemples d'application.
                  </p>
                  <div className="flex items-center text-indigo-600 text-sm font-medium">
                    <span>Consulter le lexique</span>
                    <svg className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                    </svg>
                  </div>
                </a>
                
                <a 
                  href="/tools" 
                  className="group p-6 border border-slate-200 rounded-lg hover:shadow-md transition-all duration-200 hover:border-purple-300"
                >
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-purple-200 transition-colors">
                    <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 mb-3">Écosystème d'outils</h3>
                  <p className="text-slate-600 text-sm mb-4 leading-relaxed">
                    17 outils data marketing analysés : Analytics, Visualisation, Automation, Research. 
                    Comparatifs détaillés et recommandations.
                  </p>
                  <div className="flex items-center text-purple-600 text-sm font-medium">
                    <span>Explorer les outils</span>
                    <svg className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
                  </div>
                </a>
              </div>
            </div>

            {/* Section certificats et progression */}
            <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-xl p-8">
              <h2 className="text-2xl font-bold text-slate-900 mb-6 text-center">Validez vos compétences</h2>
              <div className="text-center">
                <p className="text-slate-700 mb-6 max-w-2xl mx-auto">
                  Complétez la formation et les quiz pour développer des compétences data marketing 
                  directement valorisables en entreprise et en entretien d'embauche.
                </p>
                <a 
                  href="/quizzes" 
                  className="inline-flex items-center bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors"
                >
                  Commencer l'évaluation
                  <svg className="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
            </a>
          </div>
        </div>
          </div>
        )}

        {activeTab === 'sessions' && (
          <div className="space-y-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-slate-900 mb-4">Historique des sessions de quiz</h2>
              <p className="text-slate-600 max-w-2xl mx-auto">
                Consultez les résultats de toutes vos sessions de quiz Battle des métriques. 
                Scores par équipe, réponses détaillées et export JSON disponible.
              </p>
            </div>
            
            <QuizSessionHistory />
          </div>
        )}
      </div>
    </div>
  );
};

export default Learn; 